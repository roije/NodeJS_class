module.exports = {
    title: 'Home',
    subtitle: 'Home Page for the mandatory assignment',
    text: 'This is some text i chose to put in the paragraph'
}